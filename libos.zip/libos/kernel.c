#include <stdint.h>
#include "drivers/uart.h"
#include "shell/shell.h"

void kernel_main() {
    uart_init();  // Инициализация UART
    uart_puts("libOS v0.1\n");

    shell_init();  // Запуск оболочки
    while (1) {
        shell_prompt();
    }
}
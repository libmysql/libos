#include "uart.h"

#define MAX_CMD_LEN 64

void shell_init() {
    uart_puts("Type 'help' for commands\n");
}

void shell_prompt() {
    uart_puts("> ");
    char cmd[MAX_CMD_LEN];
    int i = 0;
    
    while (1) {
        char c = uart_getc();
        if (c == '\r') {
            uart_putc('\n');
            cmd[i] = '\0';
            shell_execute(cmd);
            return;
        } else if (c == 127 || c == '\b') {  // Backspace
            if (i > 0) {
                i--;
                uart_puts("\b \b");
            }
        } else {
            if (i < MAX_CMD_LEN - 1) {
                cmd[i++] = c;
                uart_putc(c);
            }
        }
    }
}

void shell_execute(const char *cmd) {
    if (strcmp(cmd, "help") == 0) {
        help_command();
    } else if (strcmp(cmd, "echo") == 0) {
        echo_command();
    } else if (strcmp(cmd, "meminfo") == 0) {
        meminfo_command();
    } else {
        uart_puts("Unknown command. Try 'help'.\n");
    }
}
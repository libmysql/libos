#include "../shell.h"

void help_command() {
    uart_puts(
        "Available commands:\n"
        "help    - Show this message\n"
        "echo    - Print input\n"
        "meminfo - Show memory info\n"
    );
}
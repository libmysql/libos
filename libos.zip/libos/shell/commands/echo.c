#include "../shell.h"

void echo_command() {
    uart_puts("Enter text: ");
    char buf[64];
    int i = 0;
    
    while (1) {
        char c = uart_getc();
        if (c == '\r') {
            uart_putc('\n');
            buf[i] = '\0';
            uart_puts("You typed: ");
            uart_puts(buf);
            uart_puts("\n");
            return;
        } else {
            buf[i++] = c;
            uart_putc(c);
        }
    }
}
#include "../shell.h"

void meminfo_command() {
    uart_puts("Memory: 128 MB (QEMU default)\n");
}
#define UART_BASE 0x09000000  // Адрес UART в QEMU (PL011)

void uart_init() {
    // Пока ничего не настраиваем (QEMU уже инициализировал UART)
}

void uart_putc(char c) {
    volatile uint32_t *UART_FR = (uint32_t *)(UART_BASE + 0x18);
    volatile uint32_t *UART_DR = (uint32_t *)(UART_BASE + 0x00);
    while (*UART_FR & (1 << 5));  // Ждём освобождения
    *UART_DR = c;
}

void uart_puts(const char *s) {
    while (*s) uart_putc(*s++);
}

char uart_getc() {
    volatile uint32_t *UART_FR = (uint32_t *)(UART_BASE + 0x18);
    volatile uint32_t *UART_DR = (uint32_t *)(UART_BASE + 0x00);
    while (*UART_FR & (1 << 4));  // Ждём ввода
    return (char)(*UART_DR);
}
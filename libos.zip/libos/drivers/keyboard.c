#include "../uart.h"

// Пока что просто обёртка над UART
char keyboard_getc() {
    return uart_getc();
}